import scrapy

class QuotesSpider(scrapy.Spider):
    name = "quotes"

    def start_requests(self):
        urls = [
            'https://montgomerychamber.com/events',
            'https://montgomerychamber.com/events',
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        # Print what the spider is doing
        print(response.url)
        # Get all the <a> tags
        a_selectors = response.xpath("//div[contains(@class, 'mn-title')]")
        # Loop on each tag
        for selector in a_selectors:
            # Extract the link text
            #text = selector.xpath("./data").extract_first()
            # Extract the link href
            print(selector)

            #link = selector.xpath("a").attrib['href']
            link = selector.xpath("a/text()")
            print(link)
            # Create a new Request object
            #request = response.follow(link, callback=self.parse)
            # Return it thanks to a generator
            #yield request