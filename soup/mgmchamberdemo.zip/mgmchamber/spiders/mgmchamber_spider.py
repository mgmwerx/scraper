import scrapy

class MGMChamberEventsSpider(scrapy.Spider):
    name = "mgmchamber"

    def start_requests(self):
        urls = [
            'https://montgomerychamber.com/events',
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        # Print what the spider is doing
        print(response.url)
        # Get all the <a> tags
        a_selectors = response.xpath("//div[contains(@class, 'mn-title')]")
        # Loop on each tag
        for selector in a_selectors:
            #print(selector)
            detailsPath = selector.xpath("a").attrib['href']
            print(detailsPath)
            link = selector.xpath("a/text()")
            print(link)
         