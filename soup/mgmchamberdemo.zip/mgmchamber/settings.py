
BOT_NAME = 'mgmchamber'
LOG_LEVEL = 'INFO'
SPIDER_MODULES = ['mgmchamber.spiders']
NEWSPIDER_MODULE = 'mgmchamber.spiders'

# Obey robots.txt rules
ROBOTSTXT_OBEY = False

